import { Component } from '@angular/core';

@Component({
  selector: 'app-available-books',
  standalone: true,
  imports: [],
  templateUrl: './available-books.component.html',
  styleUrl: './available-books.component.css'
})
export class AvailableBooksComponent {

}
