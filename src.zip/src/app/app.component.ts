import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { AvailableBooksComponent } from './available-books/available-books.component';
import { CustomerReviewComponent } from './customer-review/customer-review.component';
import { FeaturedBookComponent } from './featured-book/featured-book.component';
import { NavBarComponent } from './nav-bar/nav-bar.component';
import { BottomComponent } from './bottom/bottom.component';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [RouterOutlet,AvailableBooksComponent,CustomerReviewComponent,FeaturedBookComponent,NavBarComponent,BottomComponent],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent {
  title = 'bookStore';
}
