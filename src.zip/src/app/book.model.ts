export interface Book {
    id?: number;
    imgUrl: string;
    name: string;
    author: string;
    description: string;
  }
  