$(document).ready(function() {
    var books = [];

    // Fetch all books and store in the books array
    $.ajax({
        url: 'https://localhost:7012/api/books',
        type: 'GET',
        dataType: 'json',
        success: function(data) {
            books = data;
            // Do not display books here; only save data
        },
    });

    
    $("#search-button").off("click").on("click", function() {
        var searchTerm = $("#search-bar").val();

        if ($("#search-by-author").is(":checked")) {
            // Make an AJAX call to search books by author name
            $.ajax({
                url: 'https://localhost:7012/api/books/author/' + encodeURIComponent(searchTerm),
                type: 'GET',
                dataType: 'json',
                success: function(filteredBooks) {
                    displayResultsCRUD(filteredBooks);
                },
                error: function() {
                    // Handle errors, for example, when no books are found
                    displayResults([]);
                }
            });
        } else if ($("#search-by-id").is(":checked")) {
            // Validate the search term to ensure it is a number
            if (isNaN(searchTerm) || searchTerm.trim() === "") {
                alert("Please enter a valid integer.");
                return;
            }

            // Make an AJAX call to search books by ID
            $.ajax({
                url: 'https://localhost:7012/api/books/' + encodeURIComponent(searchTerm),
                type: 'GET',
                dataType: 'json',
                success: function(filteredBooks) {
                    var booksArray = Array.isArray(filteredBooks) ? filteredBooks : [filteredBooks];
                    displayResultsCRUD(booksArray);
                },
                error: function() {
                    // Handle errors, for example, when no books are found
                    displayResults([]);
                }
            });
        }
    });
        
    

    // View All functionality
    $("#viewAll").on("click", function() {
        displayResults(books);
    });

    function displayResults(results) {
        var resultsContainer = $(".gallery");
        resultsContainer.empty();

        if (results.length > 0) {
            results.forEach(function(book) {
                var bookHtml = "<div class='book'>";
                bookHtml += "<img src='" + book.imgUrl + "'>";
                bookHtml += "<p><h4>" + book.id + "|" + book.name + "</h4><p>";
                bookHtml += "<p>" + book.author + "</p>";
                bookHtml += "<p>" + book.description + "</p>";
                bookHtml += "</div>";
                resultsContainer.append(bookHtml);
            });
        } else {
            resultsContainer.html("<p>No results found.</p>");
        }
    }

    function displayResultsCRUD(results) {
        var resultsContainer = $(".gallery");
        resultsContainer.empty();

        if (results.length > 0) {
            results.forEach(function(book) {
                var bookHtml = "<div class='book'>";
                bookHtml += "<button class='delete-button' data-id=" + book.id + ">Delete</button>";
                bookHtml += "<button class='update-button' data-id=" + book.id + ">Update</button>";
                bookHtml += "<button class='add-button' data-id=" + book.id + ">Add</button>";
                bookHtml += "<img src='" + book.imgUrl + "'>";
                bookHtml += "<p><h4>" + book.id + " | " + book.name + "</h4></p>";
                bookHtml += "<p>" + book.author + "</p>";
                bookHtml += "<p>" + book.description + "</p>";
                bookHtml += "</div>";
                resultsContainer.append(bookHtml);
            });
        } else {
            resultsContainer.html("<p>No results found.</p>");
        }
    }

    // Delete functionality
    $(".gallery").on("click", ".crud-button", function() {
        var bookId = $(this).data("id");
        console.log(bookId);
        $.ajax({
            url: 'https://localhost:7012/api/books/' + encodeURIComponent(bookId),
            type: 'DELETE',
            success: function() {
                alert("Book deleted successfully.");
            },
            error: function() {
                alert("Error deleting the book.");
            }
        });
    });
});
