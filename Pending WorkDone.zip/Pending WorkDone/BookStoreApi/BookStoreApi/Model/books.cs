﻿namespace BookStoreApi.Model
{
    public class books
    {
        public int Id { get; set; }          // Assuming you have an Id property for unique identification
        public string ImgUrl { get; set; }   // Use string for the image URL
        public string Name { get; set; }
        public string Author { get; set; }
        public string Description { get; set; }
        
    }
}
