﻿using BookStoreApi.Model;

namespace BookStoreApi.DataAccessLayer
{
    public class booksDAL
    {
        private static List<books> products = new List<books>
        {
            new books { Id = 1, ImgUrl = "assets/hide&seek.png", Name = "Hide and Seek", Author = "Olivia Wilson", Description = "This Book is" },
            new books { Id = 2, ImgUrl = "assets/fiction-novel-book-cover-template.jpg", Name = "Never Ending Sky", Author = "Joseph Kirkland", Description = "This Book is" },
            new books { Id = 3, ImgUrl = "assets/fiction-novel-book-cover-template.jpg", Name = "Never Ending Sky", Author = "Joseph Kirkland", Description = "This Book is" },
            new books { Id = 4, ImgUrl = "assets/forrest-gump-1986.jpg", Name = "Forrest Gump", Author = "Winston Groom", Description = "This Book is" },
        };

        public List<books> GetProducts()
        {
            return products;
        }

        public books GetProduct(int id)
        {
            return products.FirstOrDefault(p => p.Id == id);
        }

        public void AddProduct(books product)
        {
            product.Id = products.Max(p => p.Id) + 1;
            products.Add(product);
        }

        public void UpdateProduct(books product)
        {
            var existingProduct = products.FirstOrDefault(p => p.Id == product.Id);

            if (existingProduct != null)
            {
                existingProduct.ImgUrl = product.ImgUrl;
                existingProduct.Name = product.Name;
                existingProduct.Author = product.Author;
                existingProduct.Description = product.Description;
            }
        }

        public void DeleteProduct(int id)
        {
            var product = products.First(p => p.Id == id);
            if (product != null)
            {
                products.Remove(product);
            }
        }

        public List<books> GetBooksByAuthor(string author)
        {
            return products.Where(p => p.Author == author).ToList();
        }
    }
}