﻿using BookStoreApi.DataAccessLayer;
using BookStoreApi.Model;

namespace BookStoreApi.BusinessLayer
{
    public class booksBL
    {
        private readonly booksDAL productDAL = new booksDAL();
        public List<books> GetProducts()
        {
            return productDAL.GetProducts();
        }

        public books GetProduct(int id)
        {
            return productDAL.GetProduct(id);
        }

        public void AddProduct(books product)
        {
            productDAL.AddProduct(product);
        }

        public void UpdateProduct(int id, books product)
        {
            var existingProduct = productDAL.GetProduct(id);
            if (existingProduct != null)
            {
                product.Id = id; // Ensure the ID remains unchanged
                productDAL.UpdateProduct(product);
            }
        }

        public void DeleteProduct(int id)
        {
            productDAL.DeleteProduct(id);
        }

        public List<books> GetBooksByAuthor(string author)
        {
            return productDAL.GetBooksByAuthor(author);
        }
    }
}
