$(document).ready(function() {
    var books = [];

    // Fetch all books and store in the books array
    $.ajax({
        url: 'https://localhost:7012/api/books',
        type: 'GET',
        dataType: 'json',
        success: function(data) {
            books = data;
            // Do not display books here; only save data
        },
    });

    
    
    if ($("#search-by-author").is(":checked")) 
    {
            // Search functionality
        $("#search-button").on("click", function() {
            var searchTerm = $("#search-bar").val();

            // Make an AJAX call to search books by author name
            $.ajax({
                url: 'https://localhost:7012/api/books/author/' + encodeURIComponent(searchTerm),
                type: 'GET',
                dataType: 'json',
                success: function(filteredBooks) {
                    displayResults(filteredBooks);
                },
                error: function() {
                    // Handle errors, for example, when no books are found
                    displayResults([]);
                }
            });
        });
    }
    else if ($("#search-by-id ").is(":checked"))
    {
        // Search functionality
        $("#search-button").on("click", function() {
            var searchTerm = $("#search-bar").val();

            // Make an AJAX call to search books by author name
            $.ajax({
                url: 'https://localhost:7012/api/books/' + encodeURIComponent(searchTerm),
                type: 'GET',
                dataType: 'json',
                success: function(filteredBooks) {
                    displayResults(filteredBooks);
                },
                error: function() {
                    // Handle errors, for example, when no books are found
                    displayResults([]);
                }
            });
        });
    }

    // View All functionality
    $("#viewAll").on("click", function() {
        displayResults(books);
    });

    function displayResults(results) {
        var resultsContainer = $(".gallery");
        resultsContainer.empty();

        if (results.length > 0) {
            results.forEach(function(book) {
                var bookHtml = "<div class='book'>";
                bookHtml += "<img src='" + book.imgUrl + "'>";
                bookHtml += "<p><h4>" + book.id + "|" + book.name + "</h4><p>";
                bookHtml += "<p>" + book.author + "</p>";
                bookHtml += "<p>" + book.description + "</p>";
                bookHtml += "</div>";
                resultsContainer.append(bookHtml);
            });
        } else {
            resultsContainer.html("<p>No results found.</p>");
        }
    }
});
