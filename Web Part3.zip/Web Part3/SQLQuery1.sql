USE [5580];


-- Step 2: CREATE the Products table
CREATE TABLE Books
(
    Id INT PRIMARY KEY IDENTITY(1,1),
	ImgUrl VARCHAR (200) NOT NULL,
    Name VARCHAR(100) NOT NULL,
	Author VARCHAR(100) NOT NULL,
    Description VARCHAR(500),
);


-- Insert data into the Products table
INSERT INTO Books (ImgUrl, Name, Author, Description)
VALUES
       ('assets/hide&seek.png', 'Hide and Seek', 'Olivia Wilson', 'This Book is'),
       ('assets/fiction-novel-book-cover-template.jpg', 'Never Ending Sky', 'Joseph Kirkland','This Book is');

