USE [5580];
GO

-- Stored Procedures 

--Get Products
CREATE PROCEDURE GetAllBooks
AS
BEGIN
    SELECT * FROM Books
END
GO

EXEC GetAllBooks

--Get Products By ID
CREATE PROCEDURE GetBookById
    @Id INT 
AS
BEGIN
    SELECT * FROM Books WHERE Id = @Id
END
GO

--exec GetBookById 1
-- Stored Procedure to Get Books By Author
CREATE PROCEDURE GetByAuthor
    @Author VARCHAR(100)
AS
BEGIN
    SELECT * FROM Books WHERE Author = @Author
END
GO

--EXEC GetByAuthor 'Olivia Wilson'

-- Stored Procedure to Delete Book By ID
CREATE PROCEDURE DeleteById
    @Id INT
AS
BEGIN
    DELETE FROM Books WHERE Id = @Id
END
GO

-- EXEC DeleteById 1