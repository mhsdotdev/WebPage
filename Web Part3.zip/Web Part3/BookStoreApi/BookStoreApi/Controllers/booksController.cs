using Microsoft.AspNetCore.Mvc;
using BookStoreApi.BusinessLayer;
using BookStoreApi.Model;

namespace BookStoreApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class booksController : ControllerBase
    {
        private booksBL booksBL = new booksBL();

        [HttpGet]
        public ActionResult<IEnumerable<books>> GetBooks()
        {
            var books = booksBL.GetBooks();
            return Ok(books);
        }

 
        [HttpGet("{id}")]
        public ActionResult<books> GetBook(int id)
        {
            var book = booksBL.GetBook(id);

            if (book == null)
            {
                return NotFound(new { Message = "Book not found" });
            }

            return Ok(book);
        }


        [HttpPost]
        public ActionResult<books> PostBook(books book)
        {
            booksBL.AddBook(book);
            return CreatedAtAction(nameof(GetBook), new { id = book.Id }, book);
        }

        // PUT: api/books/2
        [HttpPut("{id}")]
        public IActionResult PutBook(int id, books book)
        {
            var existingBook = booksBL.GetBook(id);
            if (existingBook == null)
            {
                return NotFound(new { Message = "Book not found" });
            }

            booksBL.UpdateBook(id, book);
            return Ok(new { Message = "Book updated successfully" });
        }

        // DELETE: api/books/1
        [HttpDelete("{id}")]
        public IActionResult DeleteBook(int id)
        {
            var existingBook = booksBL.GetBook(id);
            if (existingBook == null)
            {
                return NotFound(new { Message = "Book not found" });
            }

            booksBL.DeleteBook(id);
            return Ok(new { Message = "Book deleted successfully" });
        }

        // GET: api/books/author/hamza
        [HttpGet("author/{author}")]
        public ActionResult<IEnumerable<books>> GetBooksByAuthor(string author)
        {
            var books = booksBL.GetBooksByAuthor(author);

            if (books == null || !books.Any())
            {
                return NotFound(new { Message = "No books found for the specified author" });
            }

            return Ok(books);
        }
    }
}
