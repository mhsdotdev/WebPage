﻿using BookStoreApi.DataAccessLayer;
using BookStoreApi.Model;

namespace BookStoreApi.BusinessLayer
{
    public class booksBL
    {
        private booksDAL booksDAL = new booksDAL();

        public List<books> GetBooks()
        {
            return booksDAL.GetBooks();
        }

        public books GetBook(int id)
        {
            return booksDAL.GetBook(id);
        }

        public void AddBook(books book)
        {
            booksDAL.AddBook(book);
        }

        public void UpdateBook(int id, books book)
        {
            var existingBook = booksDAL.GetBook(id);
            if (existingBook != null)
            {
                book.Id = id;
                booksDAL.UpdateBook(book);
            }
        }

        public void DeleteBook(int id)
        {
            booksDAL.DeleteBook(id);
        }

        public List<books> GetBooksByAuthor(string author)
        {
            return booksDAL.GetBooksByAuthor(author);
        }
    }
}
