﻿using BookStoreApi.Model;
using System.Data;
using Microsoft.Data.SqlClient;

namespace BookStoreApi.DataAccessLayer
{
    public class booksDAL
    {
        private string connectionString;

        public booksDAL()
        {
            var configuration = new ConfigurationBuilder()
           .SetBasePath(Directory.GetCurrentDirectory())
           .AddJsonFile("appsettings.json")
           .Build();
            connectionString = configuration.GetConnectionString("DefaultConnection");
        }

        public List<books> GetBooks()
        {
            var books = new List<books>();
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand("GetAllBooks", conn)
                {
                    CommandType = CommandType.StoredProcedure
                };

                conn.Open();
                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        var book = new books
                        {
                            Id = (int)reader["Id"],
                            ImgUrl = reader["ImgUrl"].ToString(),
                            Name = reader["Name"].ToString(),
                            Author = reader["Author"].ToString(),
                            Description = reader["Description"].ToString()
                        };

                        books.Add(book);
                    }
                }
            }

            return books;
        }

        public books GetBook(int id)
        {
            books book = null;
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand("GetBookById", conn)
                {
                    CommandType = CommandType.StoredProcedure
                };
                cmd.Parameters.AddWithValue("@Id", id);

                conn.Open();
                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    if (reader.Read())
                    {
                        book = new books
                        {
                            Id = (int)reader["Id"],
                            ImgUrl = reader["ImgUrl"].ToString(),
                            Name = reader["Name"].ToString(),
                            Author = reader["Author"].ToString(),
                            Description = reader["Description"].ToString()
                        };
                    }
                }
            }

            return book;
        }

        public void AddBook(books book)
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand("AddBook", conn)
                {
                    CommandType = CommandType.StoredProcedure
                };

                cmd.Parameters.AddWithValue("@ImgUrl", book.ImgUrl);
                cmd.Parameters.AddWithValue("@Name", book.Name);
                cmd.Parameters.AddWithValue("@Author", book.Author);
                cmd.Parameters.AddWithValue("@Description", book.Description);

                conn.Open();
                cmd.ExecuteNonQuery();
            }
        }

        public void UpdateBook(books book)
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand("UpdateBook", conn)
                {
                    CommandType = CommandType.StoredProcedure
                };

                cmd.Parameters.AddWithValue("@Id", book.Id);
                cmd.Parameters.AddWithValue("@ImgUrl", book.ImgUrl);
                cmd.Parameters.AddWithValue("@Name", book.Name);
                cmd.Parameters.AddWithValue("@Author", book.Author);
                cmd.Parameters.AddWithValue("@Description", book.Description);

                conn.Open();
                cmd.ExecuteNonQuery();
            }
        }

        public void DeleteBook(int id)
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand("DeleteById", conn)
                {
                    CommandType = CommandType.StoredProcedure
                };

                cmd.Parameters.AddWithValue("@Id", id);

                conn.Open();
                cmd.ExecuteNonQuery();
            }
        }

        public List<books> GetBooksByAuthor(string author)
        {
            var books = new List<books>();
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand("GetByAuthor", conn)
                {
                    CommandType = CommandType.StoredProcedure
                };
                cmd.Parameters.AddWithValue("@Author", author);

                conn.Open();
                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        var book = new books
                        {
                            Id = (int)reader["Id"],
                            ImgUrl = reader["ImgUrl"].ToString(),
                            Name = reader["Name"].ToString(),
                            Author = reader["Author"].ToString(),
                            Description = reader["Description"].ToString()
                        };

                        books.Add(book);
                    }
                }
            }

            return books;
        }
    }
}
