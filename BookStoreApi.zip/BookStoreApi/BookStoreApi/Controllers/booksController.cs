using Microsoft.AspNetCore.Mvc;
using BookStoreApi.BusinessLayer;
using BookStoreApi.Model;

namespace Web_API_Lecture.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class booksController : ControllerBase
    {
        private readonly booksBL productBL = new booksBL();

        // GET: api/books
        [HttpGet]
        public ActionResult<IEnumerable<books>> GetProducts()
        {
            var products = productBL.GetProducts();
            return Ok(products);
        }

        // GET: api/books/3
        [HttpGet("{id}")]
        public ActionResult<books> GetProduct(int id)
        {
            var product = productBL.GetProduct(id);

            if (product == null)
            {
                return NotFound(new { Message = "Book not found" });
            }

            return Ok(product);
        }

        // POST: api/books
        [HttpPost]
        public ActionResult<books> PostProduct(books product)
        {
            productBL.AddProduct(product);
            //return CreatedAtAction(nameof(GetProduct), new { id = product.Id }, product);
            return Ok(product);
        }

        // PUT: api/books/2
        [HttpPut("{id}")]
        public IActionResult PutProduct(int id, books product)
        {
            var existingProduct = productBL.GetProduct(id);
            if (existingProduct == null)
            {
                return NotFound(new { Message = "Book not found" });
            }

            productBL.UpdateProduct(id, product);
            return Ok(new { Message = "Book updated successfully" });
        }

        // DELETE: api/books/1
        [HttpDelete("{id}")]
        public IActionResult DeleteProduct(int id)
        {
            var existingProduct = productBL.GetProduct(id);
            if (existingProduct == null)
            {
                return NotFound(new { Message = "Book not found" });
            }

            productBL.DeleteProduct(id);
            return Ok(new { Message = "Book deleted successfully" });
        }

        // GET: api/books/author/hamza
        [HttpGet("author/{author}")]
        public ActionResult<IEnumerable<books>> GetProductsByAuthor(string author)
        {
            var products = productBL.GetBooksByAuthor(author);

            if (products == null || !products.Any())
            {
                return NotFound(new { Message = "No books found for the specified author" });
            }

            return Ok(products);
        }

    }
}
